
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
    Author: Lucy Oliverio
    Date: 9/5/18
    Class: CS350
    Description: This is the prototype to creating a scriptable textbase game. 
Currently, the program runs on text files, in which the person creating the textbase game
can write on. When run, the game will take read off the text files.
 */
public class TestCode {
    private ArrayList<String> arr = new ArrayList<>();//This array will have all the commands stored in the text file
//This array will have all the commands stored in the text file
    private String file_name = "TestC.txt";
    private  BufferedReader br;

    public TestCode() {
        try {
            br = new BufferedReader(new FileReader(file_name));
        } catch (FileNotFoundException ex) {
            Logger.getLogger(TestCode.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
}
