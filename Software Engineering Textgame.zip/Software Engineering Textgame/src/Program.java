/*
Author: Lucy Oliverio
Date: 9/5/18
Class: CS350
Description: This is the prototype to creating a scriptable textbase game. 
Currently, the program runs on text files, in which the person creating the textbase game
can write on. When run, the game will take read off the text files.
 */
public class Program {

    /*
Author: Lucy Oliverio
Date: 9/5/18
Class: CS350
Description: This file simply runs another file's code.
     */
    public static void main(String[] args) {
        /*
        Author: Lucy Oliverio
        Date: 9/5/18
        Class: CS350
        Description: Runs the desired code, sometimes switching between the test code and actual
         */
        Code c = new Code();//useful code
        //TestCode tc = new TestCode("TestC.txt");
    }
}
