
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;


/*
Author: Lucy Oliverio
Date: 9/5/18
Class: CS350
Description: This is the prototype to creating a scriptable textbase game. 
Currently, the program runs on text files, in which the person creating the textbase game
can write on. When run, the game will take read off the text files.
 */
public class Commands{

    /*
    Author: Lucy Oliverio
    Date: 9/6/18
    Class: 350
    Description: The Command file is a collection of methods that the Code file
    can use. The Code file uses these methods for a variety of reasons: 
    Checking to see if the user inputed the correct command, pulling and displaying
    the description of the command from the text file, and dealing with other special
    commands.
     */
    private ArrayList<String> arr = new ArrayList<>();//This array will have all the commands stored in the text file
    private String file_name = null;//initilizing the variable that will store the file's name
    private FileReader fr;//initilizing the flereader
    private BufferedReader br = null;//initializing the buffered reader

    public Commands(String fn) {

        /*
    Author: Lucy Oliverio
    Date: 9/6/18
    Class: 350
    Description: Code will call Commands with an input equal to the first text file
        name. That textfile name and information will be loaded using resetComm, 
        located as a private method within the Commands file.
         */
        resetComm(fn);//sets up the first room
    }

    public boolean menu(String s) {
        /*
        Author: Lucy Oliverio
        Date: 9/6/18
        Class: 350
        Description: This method is a collection of commands that are more external
        tools to help the player.
         */
        switch (s) {//checks to see if the command is a special case
            case "help"://if it is help
                disEntireTextFile("Help.txt");//print out the entire textfile
                System.out.println("Available commands:");//print out a list of available commands
                for (String str : arr) {
                    str = str.replaceAll("_", " ");//then replace all underscores with a space
                    System.out.println(str);
                }
                System.out.println("quit\n");//and let the player know they can quit
                return true;
            case "quit"://if the command is quit, end the program
                System.out.println("Try Harder.");
                System.exit(0);
            default:
                return false;
        }
    }

    public boolean actioinIsThere(String str) {
        /*
        Author: Lucy Oliverio
        Date: 9/6/18
        Class: 350
        Description: This method checks to see if the command the player inputed
        is valid. It does this by checking the command with arr, an arraylist of
        all the commands available to the player.
         */
        str = str.replaceAll(" ", "_");//replaces the spaces in the player's command with an underscore to match the command description
        for (String s : arr) {//look through every element in the array, return false if there is no match
            if (str.equals(s)) {
                return true;
            }
        }
        return false;
    }

    public void FindText(String str) {
        /*
        Author: Lucy Oliverio
        Date: 9/6/18
        Class: 350
        Description: This method looks for the player's command, which has already
        been confirmed as valid, via actionIsThere method. The method takes the command
        the player inputed and matches it with all the commands on the textfile until
        it finds a match. It then proceeds to carryout the command as the writer intended.
         */
        str = str.replaceAll(" ", "_");//replaces all spaces with an uderscore to match the command lines
        String temp_string = null;//initilizes & declares the variables
        String[] s;
        try {
            temp_string = br.readLine();//reads the first line and stores it
        } catch (IOException ex) {
            Logger.getLogger(Commands.class.getName()).log(Level.SEVERE, null, ex);
        }
        s = temp_string.split(":");//then splits the command
        while (!s[0].equals(str)) {//while the command isn't what the user is looking for
            try {
                temp_string = br.readLine();//continue to read the next line
            } catch (IOException ex) {
                Logger.getLogger(Commands.class.getName()).log(Level.SEVERE, null, ex);
            }
            s = temp_string.split(":");//and split it
        }
        if (s[1].equals("xx")) {//if the second command is that the player has ended the program
            System.out.println(s[2]);//print out the discription
            System.exit(0);//then end the program
        } else if (s[1].equals("!x")) {//if the second command is that the player has generated a new room
            System.out.println("You are in a new area.");//let the player know
            resetComm(s[2]);//then reset everything
        } else {
            System.out.println(s[1]);//otherwise, print out the discrption
            setBuff();//reset bufferedReader to begining
        }
    }

    private void resetComm(String fn) {
        /*
        Author: Lucy Oliverio
        Date: 9/6/18
        Class: 350
        Description: This method sets the file_name, initilized at the top, to whatever is is inputed in
        when called upon. It then reads every command on that file and stores it
        into an array called arr, which was also initilized at the top. 
         */
        file_name = fn;//sets file name to whatever file is being used
        arr.clear();//clears out previous commands
        setBuff();//sets up the buffered reader to the begining
        String temp_string = null;//inilizes the variable
        String[] s = null;//inilizes the variable
        try {
            while (true) {//while the file isn't at the end
                temp_string = br.readLine();//reads in a line from the text file and attempts to store it
                if (temp_string.equals("\0")) {//if there is an empty line
                    continue;
                }
                if (temp_string.equals("*!*")) {//if its the end of the file
                    break;
                }
                s = temp_string.split(":");//using the regex, ':', split the stored command line
                arr.add(s[0]);//add only the command section to arr
            }
        } catch (IOException ex) {
            Logger.getLogger(Commands.class.getName()).log(Level.SEVERE, null, ex);
        }
        setBuff();//must reset buffer because it reached the end of the file
    }

    private void setBuff() {
        /*
        Author: Lucy Oliverio
        Date: 9/6/18
        Class: 350
        Description: This method is called when the BufferedReader has to be reset because
        of either a file is being set up or the old one has read through the file.
        It resets the buffer by creating a new BufferedReader and FileReader.
         */
        try {
            br = new BufferedReader(new FileReader(file_name));
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Commands.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void disEntireTextFile(String fileName) {
        /*
        Author: Lucy Oliverio
        Date: 9/6/18
        Class: 350
        Description: This method is used purely to display all of the textfile's content.
         */
        BufferedReader brHelp = null;//initilizes a temporary bufferedReader to use
        String str = null;//initilizes a temporary string
        try {
            brHelp = new BufferedReader(new FileReader(fileName));//sets the temporary buffered reader up to whatever file is being read
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Commands.class.getName()).log(Level.SEVERE, null, ex);
        }
        while (true) {//while it isn't the end of the file
            try {
                str = brHelp.readLine();//then set the next line in the textfile to the variable str
            } catch (IOException ex) {
            }
            if (str.equals("\0")) {
               continue;
            }
            else if (str.equals("*!*")) {
                break;
            }
            System.out.println(str);//print out whatever was on file
            }
    }
}
