
import java.util.Scanner;

/*
Author: Lucy Oliverio
Date: 9/5/18
Class: CS350
Description: This is the prototype to creating a scriptable textbase game. 
Currently, the program runs on text files, in which the person creating the textbase game
can write on. When run, the game will take read off the text files.
 */
public class Code {

    private Commands com = new Commands("Room1.txt");
    private Scanner input = new Scanner(System.in);

    public Code(){
        /*
        Author: Lucy Oliverio
        Date: 9/6/18
        Class: 350
        Description: The Code file is used to run the program in a more organized manner.
        It will run in the main, however, it does not have a main so that the methods
        do not have to be static. This file controls all other files, like a supervisor.
         */
        String com_line = null;
        System.out.println("Welcome to the textbase game trial! You are in the first room. type quit to quit.");
        while (true) {//while the player wants to play the game
            com_line = input.nextLine();//gets command
            if (com.menu(com_line)) {//if the command was part of the menu, print out what is necessary
                continue;
            }
            boolean isCommand = com.actioinIsThere(com_line);//otherwise, check to see if it is a valid command
            if (!isCommand) {//if it isn't, then let the player know to try again
                System.out.println("Not a command.");
                continue;
            }
            com.FindText(com_line);//otherwise, print out the text assoicated with the command
        }
    }
}
